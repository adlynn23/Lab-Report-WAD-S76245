<%-- 
    Document   : header
    Created on : 14 Apr 2026, 3:25:12 pm
    Author     : DELL
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<div style="background-color:cornsilk; color:black; padding:10px; text-align:center;">
        <h1>Student Club Registration</h1>
    </div>

<body>
    <nav style="background-color:#4CAF50; padding:10px;">
    <a href="RegistrationPage.jsp" style="color:white; margin-right:15px;">Register</a>
    <a href="feeCalculator.jsp" style="color:white; margin-right:15px;">Fee Calculator</a>
    <a href="memberDirectory.jsp" style="color:white; margin-right:15px;">Member Directory</a>
</nav>

</body>
