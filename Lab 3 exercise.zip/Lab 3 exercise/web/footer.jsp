<%-- 
    Document   : footer
    Created on : 14 Apr 2026, 3:25:27 pm
    Author     : DELL
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<div style="background-color:cornsilk; color:black; padding:10px; text-align:center;">
    <p>&copy; 2026 - adlynn</p>
</div>