<%-- 
    Document   : RegistrationPage
    Created on : 14 Apr 2026, 3:28:12 pm
    Author     : DELL
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>register Page</title>
    </head>
    <body>
        <%@include file="header.jsp"%>
        <h1>
            Student Registration
        </h1>
        
        <form action="processRegistration.jsp" method="post">
            <fieldset>
                <legend>Member Registration</legend>
                <label for="icno">Name:</label>
                <input type="text" id="name" name="my_name" size="45"
                       placeholder="Enter your name"><br/></br>
                <label for="matricno">Matric Number:</label>
                <input type="text" id="matricno" name="my_matricno" size="15"
                       placeholder="E.g. S123456"><br/></br>
             
                
                <label>Selected Club:</label>
                <select name="club">
                    <option value="Algebra Club">Algebra Club</option>
                    <option value="Math Club">Math Club</option>
                    <option value="Hackketon Club">Hackketon Club</option>
                </select><br/><br/>
                <input type="submit" value="Submit" />
                <input type="reset" value="Cancel" />
            </fieldset>
        </form>
    </body>
        <%@include file="footer.jsp"%>

</html>
