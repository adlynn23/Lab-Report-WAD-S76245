<%-- 
    Document   : processRegistration
    Created on : 14 Apr 2026, 3:42:29 pm
    Author     : DELL
--%>

<%@page import="java.util.ArrayList"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
</head>
<body>
    <%@include file="header.jsp"%>
    
    <fieldset>
        <%
            //define variables..
            String myMatricno = null;
            String myName = null;
            String myClub = null;
            //<!-- use request.getParameter() method to retrieve data from the form in memberRegister.jsp --> 
            myName = request.getParameter("my_name");
           myMatricno = request.getParameter("my_matricno");
            myClub = request.getParameter("club");
             // <!-- use request.getParameter() method to retrieve data from the form in memberRegister.jsp--> 
                ArrayList<String[]> memberList = (ArrayList<String[]>) session.getAttribute("memberList");
                 if (memberList == null) {
                    memberList = new ArrayList<String[]>(); // Create new list if it's the first registration
                }

                if (myName != null && myMatricno != null) {
                    memberList.add(new String[]{myName, myMatricno, myClub});
                }

                session.setAttribute("memberList", memberList);


            %>
        %>
        <!-- display the output -->
        <h2>Thank you for registering in this event..!</h2>
        <p>This is your details:</p>
        <p>Name : <%= myName%></p>
        <p>Matric No : <%= myMatricno%></p>
        <p>Club : <%=myClub%></p>
    </fieldset>
    <%@include file="footer.jsp"%>
</body>
</html>
