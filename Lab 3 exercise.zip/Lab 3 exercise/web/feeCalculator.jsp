<%-- 
    Document   : feeCalculator
    Created on : 14 Apr 2026, 3:53:20 pm
    Author     : DELL
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Membership Fee Calculator</title>
</head>
<body>
    <%@include file="header.jsp"%>
    
    <h1>Membership Fee Calculator</h1>

    <form action="feeCalculator.jsp" method="post">
        <label for="activities">Number of Activities Joined:</label>
        <input type="number" name="activities" min="0" required>
        <br/><br/>
        <p>Note: each activity joined cost RM10</p>
        <input type="submit" value="Calculate Fee">

    </form>

    <%
        String activitiesStr = request.getParameter("activities");

        if (activitiesStr != null && !activitiesStr.isEmpty()) {
            int activities = Integer.parseInt(activitiesStr);

            // Each activity costs RM10
            double totalFee = activities * 10.0;

            // Format to 2 decimal places
            java.text.DecimalFormat df = new java.text.DecimalFormat("0.00");
            String formattedFee = df.format(totalFee);

    %>
    <h3>Result:</h3>
    <p>Total Activities: <%= activities%></p>
    <p>Total Fee: RM <%= formattedFee%></p>

    <%
        }
    %>
<%@include file="footer.jsp"%>
</body>
</html>
